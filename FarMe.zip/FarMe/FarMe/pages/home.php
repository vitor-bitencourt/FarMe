<?php 
  include '../functions/functions.php'
?>

<?=template_header()?>
<link href="../style/home.css" rel="stylesheet" type="text/css">

<body>


</body>